from pathlib import Path
import json,math
R=Path(__file__).resolve().parent
cfg=json.loads((R/'config.json').read_text());orders=json.loads((R/'data/orders.json').read_text())
assert sum(o['mass_kg'] for o in orders)<=cfg['truck_capacity_kg']
for case in ['truck','normal','gust','gust_milp']:
 d=json.loads((R/'results'/f'{case}.json').read_text())
 assert sorted(r[0] for r in d['orders'])==list(range(1,cfg['orders']+1))
 assert all(r[3]<=cfg['payload_kg'] for r in d['orders'] if 'drone' in r[1])
 for key in ['truck','drone','battery']:
  rows=d[key];assert all(a[0]<=b[0]+.001 for a,b in zip(rows,rows[1:])),key
 assert all(a[1]>=b[1] for a,b in zip(d['battery'],d['battery'][1:]))
 assert min(v for _,v in d['battery'])>=cfg['reserve_Wh']
 assert abs(cfg['battery_Wh']-d['battery'][-1][1]-d['summary']['energy_Wh'])<.01
 assert abs(d['truck'][-1][1]-orders[0]['xy'][0])+abs(d['truck'][-1][2]-orders[0]['xy'][1])<.02
 assert all(a['forecast_issue_s']<=a['t_s']+.1 for a in d['audit'])
 print(case,'orders, payload, timestamps, battery, depot and issue times: PASS')
